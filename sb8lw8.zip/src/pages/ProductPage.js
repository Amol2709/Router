function ProductPage() {
  return <div>Product Page</div>;
}

export default ProductPage;
